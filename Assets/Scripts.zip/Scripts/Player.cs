﻿using System.Collections;
using System.Collections.Generic;
using UnityEngine;
[RequireComponent(typeof(Pathfinder))]
public class Player : MonoBehaviour
{
	public bool inAction = false; // If the player is currently executing an action
	public static Player Instance = null;
	Pathfinder pathfinder;
	public int[] inventory = { 0, 0, 0, 0, 0, 0, 0, 0 };
	public int[] caravan = { 0, 0, 0, 0, 0, 0, 0 };
	public static int[] caravanGoal = { 2, 2, 2, 2, 2, 2, 2 };

    // Start is called before the first frame update
    void Start()
    {
		if(Instance == null)
		{
			Instance = this;
		}
		else
		{
			Destroy(gameObject);
		}

		pathfinder = GetComponent<Pathfinder>();


    }



	IEnumerator ExecuteQueue(Queue<GoapAction> q)
	{
		while (q.Count > 0)
		{
			yield return StartCoroutine(q.Dequeue().ExecuteAction());
		}
	}

	public bool HasArrived()
	{
		return pathfinder.HasArrived();
	}

	public void GoToObject(GameObject g)
	{
		pathfinder.SetDestination(g.transform.position);
	}
	




}
